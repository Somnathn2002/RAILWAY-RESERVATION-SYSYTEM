# Railway-Reservation-System
<br><br>
This is my another mini project which is Railway reservation system.
<br>
<br>
The functionalities of this project is:-
<br>
<br>
<li>Reserving Tickets</li>
<br>
<li>Cancelling Tickets</li>
<br>
<li>Checking PNR staus</li>
<br>
<li>Checking the Train details</li>
<br>
<li>Admin privilage to update the records</li> 
<br>
<br>
<h1><b>Password for accessing admin privilage is: "*****"</b></h1>
<br><br>
  This project works purely on <b>Files concept</b> and SQL is not been used.
  <br>
  This project is made on version <b> Python 2.7</b> and may not work well with the latest versions and hence bit modifications might be required in order to run the project<br>
